
Computer Engineering 4th grade Operating Systems course final project.

## The project includes simulator for these scheduling algorithms with user friendly GUI:
1- Round Robin (RR)\
2- Completely Fair Scheduler (CFS)\
3- Shortest Remaining Time First (SRT)\
4- Multi Level Feedback Queue (MLFQ)\
5- Highest Response Ratio Next Preemptive (HRRN)\
6- Highest Response Ratio Next nonPreemptive (HRRNNP)
